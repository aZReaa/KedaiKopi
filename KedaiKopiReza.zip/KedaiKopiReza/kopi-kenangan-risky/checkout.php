<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit;
}

// Konfigurasi Midtrans
$server_key = '';
$is_production = false; // Sandbox mode untuk testing

// Set URL Midtrans
$midtrans_url = $is_production ? 'https://app.midtrans.com/snap/v1/transactions' : 'https://app.sandbox.midtrans.com/snap/v1/transactions';

// Buat order ID unik
$order_id = 'ORDER-' . time() . '-' . rand(1000, 9999);

// Siapkan data untuk Midtrans
$transaction_details = [
    'order_id' => $order_id,
    'gross_amount' => (int)$input['total']
];

$customer_details = [
    'first_name' => $input['nama'],
    'email' => $input['email'],
    'phone' => $input['phone']
];

$item_details = [];
foreach (json_decode($input['items'], true) as $item) {
    $item_details[] = [
        'id' => $item['id'],
        'price' => (int)$item['price'],
        'quantity' => (int)$item['quantity'],
        'name' => $item['name']
    ];
}

$transaction_data = [
    'transaction_details' => $transaction_details,
    'customer_details' => $customer_details,
    'item_details' => $item_details
];

// Kirim request ke Midtrans
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $midtrans_url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($transaction_data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Basic ' . base64_encode($server_key . ':')
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code === 201) {
    echo $response;
} else {
    http_response_code(500);
    $error_details = json_decode($response, true);
    echo json_encode([
        'error' => 'Failed to create transaction', 
        'http_code' => $http_code,
        'details' => $error_details,
        'raw_response' => $response
    ]);
}
?>